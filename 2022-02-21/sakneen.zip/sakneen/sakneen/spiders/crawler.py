# import json
# from scrapy.http import Request
# from sakneen.items import *
# headers = {'accept': '*/*',
#  'accept-encoding': 'gzip, deflate, br',
#  'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
#  'app-request-origin': 'sakneen-platform',
#  'content-type': 'application/json',
#  'origin': 'https://www.sakneen.com',
#  'referer': 'https://www.sakneen.com/',
#  'sec-ch-ua': '"Chromium";v="92", " Not A;Brand";v="99", "Google Chrome";v="92"',
#  'sec-ch-ua-mobile': '?0',
#  'sec-fetch-dest': 'empty',
#  'sec-fetch-mode': 'cors',
#  'sec-fetch-site': 'same-site',
#  'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36'}
#
# class SakneenKwSpider(scrapy.Spider):
#     name = 'sakneen_kw'
#     allowed_domains = ['sakneen.com']
#     def start_requests(self):
#         url="https://app.sakneen.com/apis/marketplace/filters/v2?limit=30&page=1"
#         meta={"page":1}
#         query={}
#         yield Request(url=url, callback=self.parse_search, method="POST", body=json.dumps(query),meta=meta,dont_filter=True,headers=headers)
#
#     def parse_search(self,response):
#         meta=response.meta
#         datas=json.loads(response.text)
#         datas=datas["data"]
#         for data in datas:
#             url="https://www.sakneen.com/en/house/"+str(data['slugEnglish'])
#             item=SakneenURLItem()
#             item['url'] = url
#             yield item
#
#         meta = {"page": meta['page']+1}
#         if meta['page']<=34:
#             url = "https://app.sakneen.com/apis/marketplace/filters/v2?limit=30&page="+str(meta['page'])
#             query = {}
#             yield Request(url=url, callback=self.parse_search, method="POST", body=json.dumps(query), meta=meta,
#                           dont_filter=True, headers=headers)
#
#
