import json
from scrapy.http import Request
from kw_intero.items import *
import re


class InteroSpider(scrapy.Spider):
    name = 'intero'
    allowed_domains = ['intero.com']
    def start_requests(self):
        headers = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
            "Connection": "keep-alive",
            "Host": "svc.moxiworks.com",
            "Origin": "https://intero.com",
            "Referer": "https://intero.com/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "cross-site",
            "Sec-GPC": "1",
            "Connection": "keep-alive",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36"
        }
        url="https://svc.moxiworks.com/service/profile/v2_insecure/company/3220480/agents/"
        #url='https://svc.moxiworks.com/service/profile/v2_insecure/company/3220480/agents?sr_hash=07c3a8847fe1728c638341b1922fd33eb936dcdf&sr_timestamp=1645676873&order_by=lastname%2Cfirstname&category=agent&pgsize=12&startidx=0&display_null=true&site_owner_uuid=e04c2514-8f59-47c6-80b5-47fe584c1bc9&site_type=Brokerage%20Website'
        yield Request(url=url, callback=self.parse_search, method="GET", dont_filter=True, headers=headers)
    def parse_search(self, response):
        data=(json.loads(response.text)).get("data",{})
        items=data.get("result_list",[])
        headers={
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
            "Connection": "keep-alive",
            "Host": "svc.moxiworks.com",
            "Origin": "https://intero.com",
            "Referer": "https://intero.com/",
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "cross-site",
            "Sec-GPC": "1",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36"
        }
        for item in items:
            name=item.get('display_name','').strip()
            name_list=name.split(' ')
            if len(name_list) > 3:
                first_name = name.strip()
                middle_name = ''
                last_name = ''
            elif len(name_list) == 3:
                first_name = name_list[0].strip()
                middle_name = name_list[1].strip()
                last_name = name_list[2].strip()
            elif len(name_list) == 2:
                first_name = name_list[0].strip()
                middle_name = ''
                last_name = name_list[1].strip()
            elif len(name_list) == 1:
                first_name = name_list[0].strip()
                middle_name = ''
                last_name = ''
            else:
                first_name = ''
                middle_name = ''
                last_name = ''
            if item.get("office",{}):
                office = item.get("office", {})
                if office.get("name",''):
                    office_name=office.get("name",'')
                else:
                    office_name=''
                if office.get('phone')!="":
                    office_phone_numbers=[office.get('phone')]
                else:
                    office_phone_numbers=[]
                address=(str(office.get("location",{}).get('address',''))+str(office.get("location",{}).get('address2',''))).strip()
                city=office.get("location",{}).get('city','')
                state=office.get("location",{}).get('state','')
                zipcode=office.get("location",{}).get('zip','')
                country_code = office.get("location", {}).get('country_code', '')

            profile_url="https://intero.com/directory/agents/"+str(item.get('url_slug'))

            if (item.get('image',[])[0]).get("full_url",''):
                image_url=(item.get('image',[])[0]).get("full_url",'')
            else:
                image_url=''
            title_list=["Realtor","REALTOR®","Realtor®","Realtor ®","Broker Associate","Agent / Realtor","Broker/Associate","REALTOR","Broker","SRES®","REALTORS","Realtor Associate","Agent","BROKER ASSOCIATE®","Broker/Manager","Broker Salesperson Manager","Broker/Realtor®","Consultant","Broker Associate, REALTOR","REALTOR ®","Realtor®","BROKER ASSOCIATE","Broker Assoicate","Broker/Owner","Broker Associate & Realtor©","Broker Associate/Realtor","Realtor® & Broker Associate","Professional","Broker Associate | Realtor","Realtor","Associate Broker","Broker Associate / Realtor","Broker Manager","Realtor® / Broker Associate","Realtors","REALTORS®"]
            if item.get("title",''):
                tit=[]
                for i in title_list:
                    if i==item.get("title",'').strip():
                        title=item.get("title",'').strip()
                    else:
                        if i in item.get("title",''):
                            for j in tit:
                                if j==i:
                                    continue
                                else:
                                    tit.append(i)
                if tit:
                    title=' / '.join(tit)
            else:
                title=''

            if item.get("email_display",''):
                email=item.get("email_display",'')
            else:
                email=''

            if item.get('url',''):
                website=item.get('url','')
            else:
                website=''

            agent_phone_numbers=[]
            agentnumbers=[str(item.get("cellphone")),str(item.get("alt_phone"))]
            for i in agentnumbers:
                if i!='None':
                    if i!='':
                        agent_phone_numbers.append(i)

            languages=[]
            if item.get("languages",''):
                for i in item.get("languages",''):
                    language=i.get("languagename",'')
                    languages.append(language)
            else:
                languages=[]

            items={}
            items["first_name"] = first_name
            items["middle_name"] = middle_name
            items["last_name"] = last_name
            items["office_name"] = office_name
            items['title'] = title
            items["languages"] = languages
            items["image_url"] = image_url
            items["address"] = address
            items["city"] = city
            items['state']= state
            items["zipcode"] = zipcode
            items["email"] = email
            items["website"] = website
            items["office_phone_numbers"] = office_phone_numbers
            items["agent_phone_numbers"] = agent_phone_numbers
            items["profile_url"] = profile_url
            items["country"] = country_code

            uuid=item.get('uuid')
            url='https://svc.moxiworks.com/service/v1/profile/'+str(uuid)
            yield Request(url=url, meta=items, callback=self.parse_description, method="GET", dont_filter=True, headers=headers)

    def parse_description(self,response):
        items=json.loads(response.text)
        items=items.get("data",{}).get('result_list',[])
        description=[]

        for item in items:
            contentblocks=item.get('contentblocks',[])
            for des in contentblocks:
                description.append(des.get('body',''))
            user_infos=item.get('user_info',[])
            for user_info in user_infos:
                if user_info.get('social_urls', {}):
                    facebook=user_info.get('social_urls', {}).get('facebook','')
                    linkedin=user_info.get('social_urls', {}).get('linkedin','')
                    blogger=user_info.get('social_urls', {}).get('blogger','')
                    instagram=user_info.get('social_urls', {}).get('instagram','')
                    pinterest=user_info.get('social_urls', {}).get('pinterest','')
                    twitter=user_info.get('social_urls', {}).get('twitter','')
                    youtube=user_info.get('social_urls', {}).get('youtube','')
                    print(facebook,linkedin)
                    others_urls=[]
                    social = {}
                    if facebook:
                        social["facebook"]=facebook
                    if linkedin:
                        social["linkedin"]=linkedin
                    if blogger:
                        others_urls.append(blogger)
                    if instagram:
                        others_urls.append(instagram)
                    if pinterest:
                        others_urls.append(pinterest)
                    if twitter:
                        others_urls.append(twitter)
                    if youtube:
                        others_urls.append(youtube)
                    if others_urls:
                        social["others_urls"]=others_urls
                else:
                    social={}
        description = ' '.join(description)
        if description:
            cleanr = re.compile('<.*?>')
            description = re.sub(cleanr, '', description)
            description = re.sub(r'[^\x00-\x7f]', r'', description)
            description = description.replace('\n', '').replace('\r', '').replace('\t', '').replace('\\', '').strip()

        meta=response.meta

        items=KwInteroItem()
        items["first_name"] = meta['first_name']
        items["middle_name"] = meta["middle_name"]
        items["last_name"] = meta["last_name"]
        items["office_name"] = meta["office_name"]
        items['title'] = meta['title']
        items["languages"] = meta["languages"]
        items["image_url"] = meta["image_url"]
        items["address"] = meta["address"]
        items["city"] = meta["city"]
        items['state'] = meta['state']
        items["zipcode"] = meta["zipcode"]
        items["email"] = meta["email"]
        items["website"] = meta["website"]
        items["office_phone_numbers"] = meta["office_phone_numbers"]
        items["agent_phone_numbers"] = meta["agent_phone_numbers"]
        items["social"] = social
        items["profile_url"] = meta["profile_url"]
        items["description"] = description
        items["country"] = meta["country"]
        yield items

