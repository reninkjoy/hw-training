from datetime import datetime
now = datetime.now()
day = int(now.strftime("%d"))
db_month = now
new_format = "%Y_%m"
db_date = db_month.strftime(new_format)
dbname = 'kw_monthly_' + db_date

BOT_NAME = 'kw_intero'

SPIDER_MODULES = ['kw_intero.spiders']
NEWSPIDER_MODULE = 'kw_intero.spiders'

DUP_KEY = ''
USER_AGENT = "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.87 Safari/537.36"

MONGO_URI = 'mongodb://localhost:27017'
MONGO_DB = dbname
MONGO_COLLECTION = 'intero_data'


DOWNLOADER_MIDDLEWARES = {
  #  'kw_intero.middlewares.RandomUserAgentMiddleware': 100,
    'kw_intero.middlewares.ProxyMiddleware': 110,
}
ITEM_PIPELINES = {
    'kw_intero.pipelines.KwInteroPipeline': 300,
}
# DOWNLOAD_DELAY = 1