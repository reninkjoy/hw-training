import json
from scrapy.http import Request
from sakneen.items import *
from datetime import datetime
headers={"accept": "*/*",
"accept-encoding": "gzip, deflate, br",
"accept-language": "en-GB,en-US;q=0.9,en;q=0.8",
"app-request-origin": "sakneen-platform",
"origin": "https://www.sakneen.com",
"referer": "https://www.sakneen.com/",
"sec-fetch-dest": "empty",
"sec-fetch-mode":"cors",
"sec-fetch-site": "same-site",
"sec-gpc": "1",
"user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36"}
meta={}
class SakneenKwSpider(scrapy.Spider):
    name = 'sakneen_kw'
    allowed_domains = ['sakneen.com']

    def start_requests(self):
        with open('sakneen_urls.json', 'r') as fp:
            datas = fp.read()
        datas = datas.split("\n")
        for data in datas:
            data=json.loads(data)
            url=data.get('url')
        #     url='https://www.sakneen.com/en/house/apartment-for-sale-greater-cairo-giza-sheikh-zayed-city-karma-residence-eb77d1953510413bb3c0eb6fd17aecee'
            yield Request(url=url, callback=self.parse_search, method="GET",dont_filter=True,headers=headers)

    def parse_search(self,response):
        TITLE="//h2/text()"

        title=response.xpath(TITLE).extract_first('').strip()

        main=response.url
        meta['url']=main
        meta['title']=title
        main=main.split("/")[-1]
        url="https://app.sakneen.com/apis/marketplace/listings/slug/"+str(main)
        yield Request(url=url, callback=self.parse_data,meta=meta, method="GET",dont_filter=True,headers=headers)

    def parse_data(self,response):
        meta=response.meta
        datas=json.loads(response.text)
        datas=datas.get('listing', {})
        nowdate = datetime.now().date()
        if datas:
            broker_display_name=''
            broker=''
            category_url=''
            depth=''
            sub_category_1=''
            sub_category_2=''
            price_per=''
            rera_permit_number=''
            dtcm_licence=''
            agent_name=''
            reference_number=''
            user_id=''
            finishing=''
            property_type=datas.get('unitType','')
            amenities=str(datas.get('garden',''))
            if datas.get('land'):
                land = str(datas.get('land', '')) + "m2,"
            if datas.get('bua'):
                bua=str(datas.get('bua',''))+"m2"
            details=land+bua
            id=datas.get('id', '')
            category='buy'
            description=datas.get('description','').replace('\n','').replace('\r','').replace('\t','').replace('\\','').strip()
            location=datas.get('city',{}).get("nameEnglish",'')
            price=str(datas.get('totalPrice',''))
            bedrooms=str(datas.get('bedrooms',''))
            bathrooms=str(datas.get('bathrooms'))
            scraped_ts=nowdate.strftime("%Y_%m_%d")
            number_of_photos=str(len(datas.get('photos',[])))
            phone_number=datas.get('phoneNumber','')
            iteration_number = nowdate.strftime("%Y_%m")
            latitude = datas.get('latitude','')
            if latitude==None:
                latitude=''
            else:
                latitude=str(latitude)
            longitude = datas.get('longitude','')
            if longitude==None:
                longitude=''
            else:
                longitude=str(longitude)
            published_at = datas.get('updatedAt','').split('T')[0]



        item=SakneenItem()
        item['id'] = id
        item['url'] = meta['url']
        item['broker_display_name'] = broker_display_name
        item['broker'] = broker
        item['category'] = category
        item['category_url'] = category_url
        item['title'] = meta['title']
        item['property_type'] = property_type
        item['depth'] = depth
        item['sub_category_1'] = sub_category_1
        item['sub_category_2'] = sub_category_2
        item['description'] = description
        item['location'] = location
        item['price'] = price
        item['currency'] ='EGP'
        item['price_per'] = price_per
        item['bedrooms'] = bedrooms
        item['bathrooms'] = bathrooms
        item['furnished'] = finishing
        item['rera_permit_number'] = rera_permit_number
        item['dtcm_licence'] = dtcm_licence
        item['scraped_ts'] = scraped_ts
        item['amenities'] = amenities
        item['details'] = details
        item['agent_name'] = agent_name
        item['number_of_photos'] = number_of_photos
        item['reference_number'] = reference_number
        item['user_id'] = user_id
        item['phone_number'] = phone_number
        item['date'] = scraped_ts
        item['iteration_number'] = iteration_number
        item['latitude'] = latitude
        item['longitude'] = longitude
        item['published_at'] = published_at
        yield item

